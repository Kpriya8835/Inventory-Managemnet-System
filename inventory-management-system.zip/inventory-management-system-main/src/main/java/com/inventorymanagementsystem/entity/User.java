package com.inventorymanagementsystem.entity;

public class User {
    public static String name;
}
