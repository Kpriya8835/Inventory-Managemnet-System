package com.inventorymanagementsystem.entity;

public class Invoice {
    public static String billingInvoiceNumber;
}
