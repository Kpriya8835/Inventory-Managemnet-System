package com.inventorymanagementsystem.app;

import com.inventorymanagementsystem.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.main(args);
    }
}
